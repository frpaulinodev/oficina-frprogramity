    // _____________________________________________________________________
    // MÚSICA DE LA OFICINA: emisoras reales por internet (gran variedad de géneros)
    // y canales generativos que se crean en el propio navegador (funcionan sin conexión).
    // Baja el volumen sola mientras alguien habla.
    // _____________________________________________________________________
    const MUSIC_KEY = 'frp_music_v1';
    const SOMA = (id) => `https://ice1.somafm.com/${id}-128-mp3`;
    const MUSIC_STATIONS = [
      // --- generativos (sin internet) ---
      { id: 'gen_lofi', name: 'Lo-fi para concentrarse', genre: 'Lo-fi', tags: 'lofi lo-fi chill estudiar concentrar', gen: 'lofi' },
      { id: 'gen_focus', name: 'Ambiente Focus', genre: 'Ambiente', tags: 'ambiente focus tranquilo relajante', gen: 'ambient' },
      { id: 'gen_piano', name: 'Piano tranquilo', genre: 'Piano', tags: 'piano suave calma clasica', gen: 'piano' },
      { id: 'gen_synth', name: 'Synthwave nocturno', genre: 'Synthwave', tags: 'synthwave retro 80 electro noche', gen: 'synth' },
      { id: 'gen_rain', name: 'Lluvia y café', genre: 'Sonidos', tags: 'lluvia cafe ruido blanco naturaleza', gen: 'rain' },
      // --- emisoras por internet ---
      { id: 'groovesalad', name: 'Groove Salad', genre: 'Chill / Downtempo', tags: 'chill downtempo groove relax', url: SOMA('groovesalad') },
      { id: 'gsclassic', name: 'Groove Salad Classic', genre: 'Chill clásico', tags: 'chill clasico downtempo', url: SOMA('gsclassic') },
      { id: 'fluid', name: 'Fluid', genre: 'Hip-hop instrumental', tags: 'hiphop hip hop instrumental beats lofi', url: SOMA('fluid') },
      { id: 'beatblender', name: 'Beat Blender', genre: 'Deep house', tags: 'house deep electronica baile', url: SOMA('beatblender') },
      { id: 'spacestation', name: 'Space Station', genre: 'Electrónica espacial', tags: 'electronica espacio ambient', url: SOMA('spacestation') },
      { id: 'deepspaceone', name: 'Deep Space One', genre: 'Ambient profundo', tags: 'ambient espacio profundo', url: SOMA('deepspaceone') },
      { id: 'dronezone', name: 'Drone Zone', genre: 'Ambient', tags: 'ambient drone meditar relajante', url: SOMA('dronezone') },
      { id: 'synphaera', name: 'Synphaera', genre: 'Ambient moderno', tags: 'ambient electronica moderna', url: SOMA('synphaera') },
      { id: 'defcon', name: 'DEF CON Radio', genre: 'Electrónica para programar', tags: 'programar hacker electronica codigo', url: SOMA('defcon') },
      { id: 'missioncontrol', name: 'Mission Control', genre: 'Ambient + NASA', tags: 'espacio nasa ambient', url: SOMA('missioncontrol') },
      { id: 'cliqhop', name: 'cliqhop idm', genre: 'IDM', tags: 'idm electronica experimental', url: SOMA('cliqhop') },
      { id: 'thetrip', name: 'The Trip', genre: 'Progressive house', tags: 'progressive house trance', url: SOMA('thetrip') },
      { id: 'vaporwaves', name: 'Vaporwaves', genre: 'Vaporwave', tags: 'vaporwave retro', url: SOMA('vaporwaves') },
      { id: 'dubstep', name: 'Dub Step Beyond', genre: 'Dubstep', tags: 'dubstep bass', url: SOMA('dubstep') },
      { id: 'secretagent', name: 'Secret Agent', genre: 'Lounge / Espías', tags: 'lounge jazz espias retro', url: SOMA('secretagent') },
      { id: 'lush', name: 'Lush', genre: 'Voces suaves', tags: 'voces suave pop chill', url: SOMA('lush') },
      { id: 'sonicuniverse', name: 'Sonic Universe', genre: 'Jazz moderno', tags: 'jazz moderno', url: SOMA('sonicuniverse') },
      { id: 'swissjazz', name: 'Radio Swiss Jazz', genre: 'Jazz', tags: 'jazz clasico swing', url: 'https://stream.srg-ssr.ch/m/rsj/mp3_128' },
      { id: 'swissclassic', name: 'Radio Swiss Classic', genre: 'Clásica', tags: 'clasica orquesta piano mozart bach', url: 'https://stream.srg-ssr.ch/m/rsc_de/mp3_128' },
      { id: 'swisspop', name: 'Radio Swiss Pop', genre: 'Pop', tags: 'pop exitos', url: 'https://stream.srg-ssr.ch/m/rsp/mp3_128' },
      { id: 'rpmain', name: 'Radio Paradise', genre: 'Mezcla ecléctica', tags: 'mezcla variado rock pop', url: 'https://stream.radioparadise.com/mp3-128' },
      { id: 'rpmellow', name: 'Radio Paradise Mellow', genre: 'Suave', tags: 'suave mellow tranquilo', url: 'https://stream.radioparadise.com/mellow-128' },
      { id: 'rprock', name: 'Radio Paradise Rock', genre: 'Rock', tags: 'rock guitarras', url: 'https://stream.radioparadise.com/rock-128' },
      { id: 'rpworld', name: 'Radio Paradise World', genre: 'Músicas del mundo', tags: 'mundo world latina etnica', url: 'https://stream.radioparadise.com/world-etc-128' },
      { id: 'indiepop', name: 'Indie Pop Rocks!', genre: 'Indie pop', tags: 'indie pop', url: SOMA('indiepop') },
      { id: 'poptron', name: 'PopTron', genre: 'Electropop', tags: 'electropop pop synth', url: SOMA('poptron') },
      { id: 'u80s', name: 'Underground 80s', genre: 'Años 80', tags: '80 ochenta new wave retro', url: SOMA('u80s') },
      { id: 'seventies', name: 'Left Coast 70s', genre: 'Años 70', tags: '70 setenta rock clasico', url: SOMA('seventies') },
      { id: 'bagel', name: 'BAGeL Radio', genre: 'Rock alternativo', tags: 'rock alternativo indie', url: SOMA('bagel') },
      { id: 'metal', name: 'Metal Detector', genre: 'Metal', tags: 'metal heavy', url: SOMA('metal') },
      { id: 'folkfwd', name: 'Folk Forward', genre: 'Folk', tags: 'folk acustico', url: SOMA('folkfwd') },
      { id: 'bootliquor', name: 'Boot Liquor', genre: 'Americana / Country', tags: 'country americana', url: SOMA('bootliquor') },
      { id: 'thistle', name: 'ThistleRadio', genre: 'Celta', tags: 'celta irlandesa folk', url: SOMA('thistle') },
      { id: 'suburbsofgoa', name: 'Suburbs of Goa', genre: 'Asia / Desi', tags: 'india asia mundo', url: SOMA('suburbsofgoa') },
      { id: 'illstreet', name: 'Illinois Street Lounge', genre: 'Lounge clásico', tags: 'lounge exotica retro', url: SOMA('illstreet') },
      { id: 'covers', name: 'Covers', genre: 'Versiones', tags: 'versiones covers', url: SOMA('covers') },
      { id: 'digitalis', name: 'Digitalis', genre: 'Electrónica alternativa', tags: 'electronica alternativa', url: SOMA('digitalis') }
    ];

    const MUSIC = { station: null, playing: false, volume: 0.45, onlyWork: false, filter: 'todas', audio: null, ctx: null, gen: null, duck: false, error: '' };
    try {
      const s = JSON.parse(localStorage.getItem(MUSIC_KEY) || '{}') || {};
      if (MUSIC_STATIONS.some(x => x.id === s.station)) MUSIC.station = s.station;
      if (Number.isFinite(s.volume)) MUSIC.volume = Math.max(0, Math.min(1, s.volume));
      MUSIC.onlyWork = !!s.onlyWork;
    } catch (e) { /* valores por defecto */ }

    function saveMusic() {
      try { localStorage.setItem(MUSIC_KEY, JSON.stringify({ station: MUSIC.station, volume: MUSIC.volume, onlyWork: MUSIC.onlyWork })); } catch (e) { /* sin persistencia */ }
    }

    function stationById(id) { return MUSIC_STATIONS.find(s => s.id === id) || null; }

    function effectiveVolume() { return MUSIC.volume * (MUSIC.duck ? 0.25 : 1); }

    function applyVolume() {
      if (MUSIC.audio) MUSIC.audio.volume = effectiveVolume();
      if (MUSIC.gen && MUSIC.ctx) MUSIC.gen.master.gain.setTargetAtTime(effectiveVolume() * 0.6, MUSIC.ctx.currentTime, 0.25);
    }

    function musicDuck(on) {
      if (MUSIC.duck === !!on) return;
      MUSIC.duck = !!on;
      applyVolume();
    }

    function stopAllAudio() {
      if (MUSIC.audio) { MUSIC.audio.pause(); MUSIC.audio.removeAttribute('src'); MUSIC.audio.load(); }
      if (MUSIC.gen) { MUSIC.gen.stop(); MUSIC.gen = null; }
    }

    function musicPlay(id) {
      const st = stationById(id || MUSIC.station) || MUSIC_STATIONS[0];
      stopAllAudio();
      MUSIC.station = st.id;
      MUSIC.error = '';
      MUSIC.playing = true;
      saveMusic();
      if (st.gen) {
        try {
          if (!MUSIC.ctx) MUSIC.ctx = new (window.AudioContext || window.webkitAudioContext)();
          if (MUSIC.ctx.state === 'suspended') MUSIC.ctx.resume();
          MUSIC.gen = createGenerative(MUSIC.ctx, st.gen);
          applyVolume();
        } catch (e) { MUSIC.playing = false; MUSIC.error = 'Tu navegador no permite audio generado.'; }
      } else {
        if (!MUSIC.audio) {
          MUSIC.audio = new Audio();
          MUSIC.audio.preload = 'none';
          MUSIC.audio.addEventListener('error', () => {
            if (!MUSIC.playing || !MUSIC.audio.getAttribute('src')) return;
            MUSIC.error = 'No se pudo conectar con la emisora. Prueba otra o un canal generativo.';
            MUSIC.playing = false;
            renderMusicPanel();
            updateMusicChip();
          });
        }
        MUSIC.audio.src = st.url;
        applyVolume();
        const pr = MUSIC.audio.play();
        if (pr && pr.catch) pr.catch(() => { MUSIC.playing = false; MUSIC.error = 'Pulsa ▶ para empezar (el navegador pide un clic).'; renderMusicPanel(); updateMusicChip(); });
      }
      renderMusicPanel();
      updateMusicChip();
      return st;
    }

    function musicStop() {
      stopAllAudio();
      MUSIC.playing = false;
      renderMusicPanel();
      updateMusicChip();
    }

    function musicToggle() {
      if (MUSIC.playing) musicStop(); else musicPlay(MUSIC.station);
    }

    function musicStep(dir) {
      const list = filteredStations();
      const i = Math.max(0, list.findIndex(s => s.id === MUSIC.station));
      musicPlay(list[(i + dir + list.length) % list.length].id);
    }

    function musicPlayByQuery(q) {
      const words = String(q).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').split(/\W+/).filter(w => w.length > 2 && !['pon', 'ponme', 'musica', 'radio', 'reproduce', 'algo', 'una', 'para', 'por', 'favor', 'cancion', 'canciones', 'quiero', 'escuchar'].includes(w));
      const norm = (s) => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
      let best = null, score = 0;
      MUSIC_STATIONS.forEach(st => {
        const hay = norm(st.name + ' ' + st.genre + ' ' + st.tags);
        const sc = words.reduce((s, w) => s + (hay.includes(w) ? 1 : 0), 0);
        if (sc > score) { score = sc; best = st; }
      });
      return musicPlay((best || stationById(MUSIC.station) || MUSIC_STATIONS[0]).id);
    }

    function setMusicVolume(v) {
      MUSIC.volume = Math.max(0, Math.min(1, Number(v) || 0));
      applyVolume();
      saveMusic();
    }

    function setMusicFilter(f) {
      MUSIC.filter = f;
      renderMusicPanel();
    }

    function filteredStations() {
      if (MUSIC.filter === 'offline') return MUSIC_STATIONS.filter(s => s.gen);
      if (MUSIC.filter === 'online') return MUSIC_STATIONS.filter(s => s.url);
      return MUSIC_STATIONS;
    }

    // Pausa automática fuera del horario de trabajo (si lo activas)
    let _musicPausedBySchedule = false;
    function musicScheduleTick() {
      if (!MUSIC.onlyWork || typeof currentScheduleBlock !== 'function') return;
      const working = currentScheduleBlock().kind === 'trabajo';
      if (!working && MUSIC.playing) { _musicPausedBySchedule = true; musicStop(); showToast('🎧 Música en pausa durante el descanso'); }
      else if (working && _musicPausedBySchedule) { _musicPausedBySchedule = false; musicPlay(MUSIC.station); }
    }
    setInterval(musicScheduleTick, 5000);

    function updateMusicChip() {
      const el = document.getElementById('dock-music-dot');
      if (el) el.classList.toggle('hidden', !MUSIC.playing);
    }

    function renderMusicPanel() {
      const box = document.getElementById('dock-panel-music');
      if (!box) return;
      const st = stationById(MUSIC.station);
      const list = filteredStations();
      box.innerHTML = `
        <div class="panel-head"><span>🎧 Música (${MUSIC_STATIONS.length} canales)</span><button class="icon-btn" onclick="closeDockPanel()">✕</button></div>
        <div class="p-2.5 space-y-2">
          <div class="flex items-center gap-2 p-2 rounded-xl bg-slate-950 border border-slate-800">
            <div class="eq ${MUSIC.playing ? 'on' : ''}"><i></i><i></i><i></i><i></i></div>
            <div class="min-w-0 flex-1">
              <div class="text-[11px] font-bold text-white truncate">${st ? escapeHtml(st.name) : 'Elige un canal'}</div>
              <div class="text-[10px] ${MUSIC.error ? 'text-rose-300' : 'text-slate-400'} truncate">${MUSIC.error ? escapeHtml(MUSIC.error) : st ? escapeHtml(st.genre) + (st.gen ? ' · sin internet' : ' · en vivo') : ''}</div>
            </div>
            <button class="icon-btn" onclick="musicStep(-1)" title="Anterior">⏮</button>
            <button class="play-btn" onclick="musicToggle()" title="${MUSIC.playing ? 'Pausar' : 'Reproducir'}">${MUSIC.playing ? '⏸' : '▶'}</button>
            <button class="icon-btn" onclick="musicStep(1)" title="Siguiente">⏭</button>
          </div>
          <div class="flex items-center gap-2 text-[10px] text-slate-400">
            🔈<input type="range" min="0" max="1" step="0.01" value="${MUSIC.volume}" oninput="setMusicVolume(this.value)" class="flex-1 accent-cyan-400">🔊
          </div>
          <label class="flex items-center gap-1.5 text-[10px] text-slate-300 cursor-pointer"><input type="checkbox" ${MUSIC.onlyWork ? 'checked' : ''} onchange="MUSIC.onlyWork=this.checked; saveMusic()" class="accent-cyan-400"> Sonar solo en horario de trabajo</label>
          <div class="flex gap-1">${[['todas', 'Todas'], ['online', 'En vivo'], ['offline', 'Sin internet']].map(([k, l]) => `<button onclick="setMusicFilter('${k}')" class="seg ${MUSIC.filter === k ? 'on' : ''}">${l}</button>`).join('')}</div>
          <div class="music-list quick-scroll">
            ${list.map(s => `
              <button onclick="musicPlay('${s.id}')" class="music-row ${s.id === MUSIC.station ? 'on' : ''}">
                <span class="truncate">${s.id === MUSIC.station && MUSIC.playing ? '▶ ' : ''}${escapeHtml(s.name)}</span>
                <span class="text-[9px] text-slate-500 shrink-0">${escapeHtml(s.genre)}</span>
              </button>`).join('')}
          </div>
          <p class="text-[9px] text-slate-500">Emisoras: SomaFM, Radio Swiss y Radio Paradise (radio pública por internet).</p>
        </div>`;
    }

    // _____________________________________________________________________
    // Música generativa con Web Audio (acordes, melodía y ritmo suaves en bucle)
    // _____________________________________________________________________
    function createGenerative(ctx, style) {
      const master = ctx.createGain();
      master.gain.value = 0;
      const comp = ctx.createDynamicsCompressor();
      master.connect(comp);
      comp.connect(ctx.destination);
      // reverberación sencilla con eco
      const delay = ctx.createDelay(1.0);
      delay.delayTime.value = style === 'synth' ? 0.33 : 0.42;
      const fb = ctx.createGain();
      fb.gain.value = 0.32;
      const wet = ctx.createGain();
      wet.gain.value = style === 'ambient' ? 0.5 : 0.25;
      delay.connect(fb); fb.connect(delay); delay.connect(wet); wet.connect(master);
      const bus = ctx.createGain();
      bus.connect(master); bus.connect(delay);

      const noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
      const nd = noiseBuf.getChannelData(0);
      for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;

      const PROG = {
        lofi: [[57, 60, 64, 67], [53, 57, 60, 64], [55, 59, 62, 65], [52, 55, 59, 62]],
        ambient: [[50, 57, 62, 66], [47, 54, 59, 62], [43, 50, 55, 59], [45, 52, 57, 61]],
        piano: [[48, 55, 60, 64], [45, 52, 57, 60], [41, 48, 53, 57], [43, 50, 55, 59]],
        synth: [[45, 52, 57, 60], [41, 48, 53, 57], [48, 55, 60, 64], [43, 50, 55, 59]],
        rain: [[50, 57, 62, 65], [46, 53, 58, 62]]
      }[style] || [[57, 60, 64, 67]];
      const bpm = { lofi: 76, ambient: 50, piano: 66, synth: 98, rain: 54 }[style] || 70;
      const beat = 60 / bpm;
      const hz = (m) => 440 * Math.pow(2, (m - 69) / 12);
      const nodes = new Set();

      function tone(midi, t, dur, type, vol, cutoff = 2400, attack = 0.02) {
        const o = ctx.createOscillator(), g = ctx.createGain(), f = ctx.createBiquadFilter();
        o.type = type; o.frequency.value = hz(midi);
        f.type = 'lowpass'; f.frequency.value = cutoff;
        g.gain.setValueAtTime(0, t);
        g.gain.linearRampToValueAtTime(vol, t + attack);
        g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
        o.connect(f); f.connect(g); g.connect(bus);
        o.start(t); o.stop(t + dur + 0.05);
        nodes.add(o); o.onended = () => nodes.delete(o);
      }
      function noiseHit(t, dur, vol, freq, type = 'highpass') {
        const s = ctx.createBufferSource(), g = ctx.createGain(), f = ctx.createBiquadFilter();
        s.buffer = noiseBuf; f.type = type; f.frequency.value = freq;
        g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
        s.connect(f); f.connect(g); g.connect(master);
        s.start(t, Math.random()); s.stop(t + dur + 0.02);
        nodes.add(s); s.onended = () => nodes.delete(s);
      }
      function kick(t, vol) {
        const o = ctx.createOscillator(), g = ctx.createGain();
        o.frequency.setValueAtTime(120, t); o.frequency.exponentialRampToValueAtTime(42, t + 0.18);
        g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.3);
        o.connect(g); g.connect(master); o.start(t); o.stop(t + 0.32);
        nodes.add(o); o.onended = () => nodes.delete(o);
      }

      // lluvia continua (solo en el canal de lluvia, y suave en lo-fi)
      let rain = null;
      if (style === 'rain' || style === 'lofi') {
        rain = ctx.createBufferSource();
        rain.buffer = noiseBuf; rain.loop = true;
        const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = style === 'rain' ? 1400 : 3500; f.Q.value = 0.6;
        const g = ctx.createGain(); g.gain.value = style === 'rain' ? 0.22 : 0.025;
        rain.connect(f); f.connect(g); g.connect(master);
        rain.start();
      }

      let bar = 0, nextTime = ctx.currentTime + 0.15, stopped = false;
      const scale = [0, 2, 3, 5, 7, 9, 10];
      function scheduleBar(t) {
        const chord = PROG[bar % PROG.length];
        const len = beat * 4;
        if (style === 'ambient' || style === 'rain') {
          chord.forEach((m, i) => tone(m, t + i * 0.12, len * 1.6, 'sine', 0.05, 1200, 1.2));
          if (Math.random() < 0.6) tone(chord[3] + 12 + randPick([0, 2, 5]), t + beat * 2, beat * 3, 'triangle', 0.03, 2000, 0.4);
        } else if (style === 'piano') {
          tone(chord[0] - 12, t, len, 'triangle', 0.08, 1500, 0.01);
          for (let i = 0; i < 8; i++) if (Math.random() < 0.75) tone(chord[i % 4] + (i > 3 ? 12 : 0), t + i * beat / 2, beat * 1.6, 'triangle', 0.05, 2600, 0.005);
        } else if (style === 'synth') {
          chord.forEach(m => { tone(m, t, len, 'sawtooth', 0.018, 1100, 0.3); tone(m + 0.08, t, len, 'sawtooth', 0.014, 1100, 0.3); });
          for (let i = 0; i < 8; i++) tone(chord[0] - 12 + (i % 2 ? 12 : 0), t + i * beat / 2, beat / 2.2, 'square', 0.03, 700, 0.005);
          for (let i = 0; i < 4; i++) { kick(t + i * beat, 0.35); noiseHit(t + i * beat + beat / 2, 0.06, 0.05, 7000); }
          if (bar % 2) noiseHit(t + beat * 1, 0.2, 0.12, 1800, 'bandpass'), noiseHit(t + beat * 3, 0.2, 0.12, 1800, 'bandpass');
        } else { // lofi
          chord.forEach((m, i) => tone(m, t + i * 0.03, len * 0.95, 'triangle', 0.035, 1300, 0.04));
          tone(chord[0] - 12, t, beat * 1.5, 'sine', 0.12, 600, 0.01);
          tone(chord[0] - 12, t + beat * 2.5, beat, 'sine', 0.09, 600, 0.01);
          kick(t, 0.32); kick(t + beat * 2.5, 0.22);
          for (let i = 0; i < 8; i++) noiseHit(t + i * beat / 2 + (i % 2 ? 0.03 : 0), 0.04, i % 2 ? 0.02 : 0.035, 8000);
          noiseHit(t + beat, 0.16, 0.08, 1500, 'bandpass'); noiseHit(t + beat * 3, 0.16, 0.08, 1500, 'bandpass');
          const root = chord[0] + 12;
          for (let i = 0; i < 4; i++) if (Math.random() < 0.55) tone(root + scale[Math.floor(Math.random() * scale.length)], t + i * beat + (Math.random() < 0.3 ? beat / 2 : 0), beat * 0.9, 'sine', 0.045, 2200, 0.01);
        }
        bar++;
        return len;
      }
      const timer = setInterval(() => {
        if (stopped) return;
        while (nextTime < ctx.currentTime + 1.2) nextTime += scheduleBar(nextTime);
      }, 250);

      return {
        master,
        stop() {
          stopped = true;
          clearInterval(timer);
          const t = ctx.currentTime;
          master.gain.cancelScheduledValues(t);
          master.gain.setTargetAtTime(0, t, 0.15);
          setTimeout(() => {
            nodes.forEach(n => { try { n.stop(); } catch (e) { /* ya parado */ } });
            if (rain) try { rain.stop(); } catch (e) { /* ya parado */ }
            master.disconnect();
          }, 600);
        }
      };
    }
