    // _____________________________________________________________________
    // VOZ: los empleados, clientes y el asistente hablan (síntesis de voz del navegador)
    // y tú hablas con el micrófono (reconocimiento de voz). Incluye la "sala de llamada"
    // que usan las reuniones, las llamadas con clientes y el asistente.
    // _____________________________________________________________________
    const VOICE_KEY = 'frp_voice_v1';
    const VOICE = { enabled: true, voices: [], rec: null, listening: false, speakingId: null };

    try { VOICE.enabled = localStorage.getItem(VOICE_KEY) !== 'off'; } catch (e) { /* por defecto activada */ }

    // ¿El navegador puede hablar? (algunos no traen síntesis de voz)
    function hasTTS() {
      return typeof window.speechSynthesis !== 'undefined' && !!window.speechSynthesis && typeof window.SpeechSynthesisUtterance !== 'undefined';
    }

    function loadVoices() {
      if (!(hasTTS())) return;
      const all = speechSynthesis.getVoices();
      const es = all.filter(v => /^es/i.test(v.lang));
      VOICE.voices = es.length ? es : all;
    }
    if (hasTTS()) {
      loadVoices();
      speechSynthesis.onvoiceschanged = loadVoices;
    }

    function setVoiceEnabled(on) {
      VOICE.enabled = !!on;
      try { localStorage.setItem(VOICE_KEY, on ? 'on' : 'off'); } catch (e) { /* sin persistencia */ }
      if (!on && hasTTS()) speechSynthesis.cancel();
      renderVoiceRoom();
    }

    // Voz estable por persona: misma voz y tono cada vez que habla
    function voiceProfile(id, name) {
      const h = officeHash(String(id || name || 'x'));
      const first = String(name || '').split(' ')[0].toLowerCase();
      const high = /a$/.test(first) || /lucía|inés|abril|noa|isabel|carmen|sofía/.test(first);
      const list = VOICE.voices;
      return {
        voice: list.length ? list[h % list.length] : null,
        pitch: (high ? 1.12 : 0.88) + ((h >> 3) % 10) / 100,
        rate: 1.0 + ((h >> 5) % 8) / 100
      };
    }

    function speak(text, who = {}) {
      return new Promise(resolve => {
        if (!VOICE.enabled || !(hasTTS()) || !text) { setTimeout(resolve, Math.min(4000, 400 + String(text).length * 35)); return; }
        const u = new SpeechSynthesisUtterance(String(text).replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu, '').slice(0, 400));
        const prof = voiceProfile(who.id, who.name);
        if (prof.voice) u.voice = prof.voice;
        u.lang = (prof.voice && prof.voice.lang) || 'es-ES';
        u.pitch = prof.pitch;
        u.rate = prof.rate;
        let done = false;
        const finish = () => {
          if (done) return;
          done = true;
          VOICE.speakingId = null;
          if (typeof musicDuck === 'function') musicDuck(false);
          renderVoiceRoomParticipants();
          resolve();
        };
        u.onstart = () => {
          VOICE.speakingId = who.id || null;
          if (typeof musicDuck === 'function') musicDuck(true);
          renderVoiceRoomParticipants();
        };
        u.onend = finish;
        u.onerror = finish;
        setTimeout(finish, 15000 + String(text).length * 80); // seguro por si el navegador no avisa
        try { speechSynthesis.speak(u); } catch (e) { finish(); }
      });
    }

    function canListen() {
      return !!(window.SpeechRecognition || window.webkitSpeechRecognition);
    }

    function stopListening() {
      if (VOICE.rec) { try { VOICE.rec.stop(); } catch (e) { /* ya parado */ } }
    }

    // Escucha una frase y la entrega ya transcrita
    function startListening(onFinal, onInterim) {
      if (!canListen()) { showToast('Tu navegador no permite dictado por voz: escribe el mensaje (Chrome o Edge sí lo permiten).'); return false; }
      if (VOICE.listening) { stopListening(); return false; }
      if (hasTTS()) speechSynthesis.cancel();
      const Rec = window.SpeechRecognition || window.webkitSpeechRecognition;
      const rec = new Rec();
      rec.lang = 'es-ES';
      rec.interimResults = true;
      rec.continuous = false;
      rec.maxAlternatives = 1;
      let finalText = '';
      rec.onresult = (ev) => {
        let interim = '';
        for (let i = ev.resultIndex; i < ev.results.length; i++) {
          const r = ev.results[i];
          if (r.isFinal) finalText += r[0].transcript;
          else interim += r[0].transcript;
        }
        if (onInterim) onInterim(finalText + interim);
      };
      rec.onerror = (ev) => {
        if (ev.error === 'not-allowed' || ev.error === 'service-not-allowed') showToast('🎙️ Permite el micrófono en el navegador para hablar.');
        else if (ev.error === 'no-speech') showToast('🎙️ No te escuché: inténtalo de nuevo.');
      };
      rec.onend = () => {
        VOICE.listening = false;
        VOICE.rec = null;
        if (typeof musicDuck === 'function') musicDuck(false);
        renderVoiceRoom();
        const t = finalText.trim();
        if (t && onFinal) onFinal(t);
      };
      VOICE.rec = rec;
      VOICE.listening = true;
      if (typeof musicDuck === 'function') musicDuck(true);
      try { rec.start(); } catch (e) { VOICE.listening = false; VOICE.rec = null; return false; }
      renderVoiceRoom();
      return true;
    }

    // _____________________________________________________________________
    // SALA DE LLAMADA (reuniones, clientes, asistente)
    // _____________________________________________________________________
    const ROOM = { open: false, kind: '', title: '', subtitle: '', participants: [], transcript: [], busy: false, onSay: null, onClose: null, startedAt: 0, timer: null, interim: '', actions: '' };

    function initials(name) {
      return String(name || '?').replace(/ IA$/, '').split(/\s+/).map(w => w[0] || '').join('').slice(0, 2).toUpperCase();
    }

    function openVoiceRoom(opts) {
      if (ROOM.open) closeVoiceRoom(true);
      Object.assign(ROOM, {
        open: true, kind: opts.kind || 'call', title: opts.title || 'Llamada', subtitle: opts.subtitle || '',
        participants: opts.participants || [], transcript: [], busy: false, onSay: opts.onUserSay || null,
        onClose: opts.onClose || null, startedAt: Date.now(), interim: '', actions: opts.actions || ''
      });
      const el = document.getElementById('voice-room');
      el.classList.remove('hidden');
      renderVoiceRoom();
      clearInterval(ROOM.timer);
      ROOM.timer = setInterval(() => {
        const t = document.getElementById('vr-time');
        if (!t || !ROOM.open) return;
        const s = Math.floor((Date.now() - ROOM.startedAt) / 1000);
        t.textContent = String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
      }, 1000);
      if (opts.greeting && opts.greeting.length) roomSpeakAll(opts.greeting);
    }

    function closeVoiceRoom(silent = false) {
      if (!ROOM.open) return;
      ROOM.open = false;
      clearInterval(ROOM.timer);
      stopListening();
      if (hasTTS()) speechSynthesis.cancel();
      document.getElementById('voice-room').classList.add('hidden');
      const cb = ROOM.onClose;
      ROOM.onClose = null;
      if (cb && !silent) cb(ROOM.transcript.slice());
      else if (cb) cb(ROOM.transcript.slice(), true);
    }

    function roomParticipant(nameOrId) {
      const key = String(nameOrId || '').toLowerCase();
      return ROOM.participants.find(p => p.id === nameOrId) ||
        ROOM.participants.find(p => p.name.toLowerCase() === key) ||
        ROOM.participants.find(p => key && p.name.toLowerCase().startsWith(key.split(' ')[0])) || null;
    }

    function roomAdd(who, text) {
      ROOM.transcript.push({ who: who ? who.name : 'Tú', id: who ? who.id : 'me', color: who ? who.color : null, text });
      if (ROOM.transcript.length > 60) ROOM.transcript.shift();
      renderVoiceRoomTranscript();
    }

    // Habla cada respuesta en orden: texto en la sala, burbuja en 3D y voz.
    // Las intervenciones se encadenan para que nunca se pisen dos voces.
    let _roomSpeech = Promise.resolve();
    function roomSpeakAll(replies) {
      const session = ROOM.startedAt;
      _roomSpeech = _roomSpeech.then(() => speakReplies(replies, session)).catch(() => {});
      return _roomSpeech;
    }

    async function speakReplies(replies, session) {
      for (const r of replies) {
        if (!ROOM.open || ROOM.startedAt !== session) return;
        const who = roomParticipant(r.id || r.name) || ROOM.participants[0];
        if (!who || !r.text) continue;
        roomAdd(who, r.text);
        const ag = who.agentId && AGENTS.find(a => a.id === who.agentId);
        if (ag) ag.bubble = '💬 ' + (r.text.length > 34 ? r.text.slice(0, 34) + '…' : r.text);
        await speak(r.text, who);
      }
    }

    async function roomUserSays(text) {
      text = String(text || '').trim().slice(0, 500);
      if (!text || !ROOM.open || ROOM.busy) return;
      ROOM.interim = '';
      roomAdd(null, text);
      if (!ROOM.onSay) return;
      ROOM.busy = true;
      renderVoiceRoom();
      let replies = [];
      try { replies = await ROOM.onSay(text, ROOM.transcript.slice()); } catch (e) { console.warn(e); replies = []; }
      ROOM.busy = false;
      renderVoiceRoom();
      if (replies && replies.length) await roomSpeakAll(replies);
    }

    function roomMic() {
      startListening(t => roomUserSays(t), t => {
        ROOM.interim = t;
        const el = document.getElementById('vr-interim');
        if (el) el.textContent = t ? '🎙️ ' + t : '';
      });
    }

    function roomSubmit(e) {
      e.preventDefault();
      const inp = document.getElementById('vr-input');
      const v = inp.value;
      inp.value = '';
      roomUserSays(v);
    }

    function renderVoiceRoomParticipants() {
      const box = document.getElementById('vr-people');
      if (!box || !ROOM.open) return;
      box.innerHTML = ROOM.participants.slice(0, 16).map(p => {
        const talking = VOICE.speakingId === p.id;
        return `<div class="vr-person ${talking ? 'talking' : ''}" title="${escapeHtml(p.name)}${p.role ? ' · ' + escapeHtml(p.role) : ''}">
          <span class="vr-avatar" style="background:${p.color || '#334155'}">${escapeHtml(initials(p.name))}</span>
          <span class="vr-name">${escapeHtml(p.name.replace(/ IA$/, ''))}</span>
        </div>`;
      }).join('');
    }

    function renderVoiceRoomTranscript() {
      const box = document.getElementById('vr-log');
      if (!box) return;
      box.innerHTML = ROOM.transcript.length ? ROOM.transcript.map(t => `
        <div class="vr-line ${t.id === 'me' ? 'me' : ''}">
          <b style="${t.color ? `color:${t.color}` : ''}">${escapeHtml(t.who)}</b> ${escapeHtml(t.text)}
        </div>`).join('') : `<div class="text-[11px] text-slate-500 text-center py-3">${canListen() ? 'Pulsa 🎙️ y habla, o escribe abajo.' : 'Escribe tu mensaje abajo.'}</div>`;
      box.scrollTop = box.scrollHeight;
    }

    function renderVoiceRoom() {
      const el = document.getElementById('voice-room');
      if (!el || !ROOM.open) return;
      const icon = ROOM.kind === 'meeting' ? '📊' : ROOM.kind === 'client' ? '📞' : ROOM.kind === 'motivation' ? '🔥' : '🤖';
      el.innerHTML = `
        <div class="flex items-center justify-between gap-2 px-3 py-2 border-b border-slate-800">
          <div class="min-w-0">
            <div class="flex items-center gap-1.5 text-xs font-bold text-white truncate"><span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>${icon} ${escapeHtml(ROOM.title)}</div>
            <div class="text-[10px] text-slate-400 truncate">${escapeHtml(ROOM.subtitle)} · <span id="vr-time" class="font-mono">00:00</span></div>
          </div>
          <div class="flex items-center gap-1 shrink-0">
            <button onclick="setVoiceEnabled(!VOICE.enabled)" title="${VOICE.enabled ? 'Silenciar voces' : 'Activar voces'}" class="icon-btn">${VOICE.enabled ? '🔊' : '🔇'}</button>
            <button onclick="closeVoiceRoom()" class="px-2 py-1 rounded-lg bg-rose-500 hover:bg-rose-400 text-white text-[10px] font-bold">Colgar</button>
          </div>
        </div>
        <div id="vr-people" class="flex gap-2 px-3 pt-2 overflow-x-auto quick-scroll"></div>
        <div id="vr-log" class="vr-log"></div>
        <div id="vr-interim" class="px-3 text-[10px] text-cyan-300 h-3.5 truncate">${ROOM.busy ? '✍️ Pensando la respuesta…' : ''}</div>
        ${ROOM.actions ? `<div class="px-3 pb-1 flex flex-wrap gap-1">${ROOM.actions}</div>` : ''}
        <form onsubmit="roomSubmit(event)" class="flex items-center gap-1.5 p-2 border-t border-slate-800">
          <button type="button" onclick="roomMic()" title="Hablar" class="mic-btn ${VOICE.listening ? 'on' : ''}">${VOICE.listening ? '■' : '🎙️'}</button>
          <input id="vr-input" maxlength="500" autocomplete="off" placeholder="${VOICE.listening ? 'Te escucho…' : 'Escribe o pulsa el micrófono'}" class="flex-1 min-w-0 bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400" />
          <button type="submit" ${ROOM.busy ? 'disabled' : ''} class="px-3 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 text-slate-950 font-semibold text-xs">➤</button>
        </form>`;
      renderVoiceRoomParticipants();
      renderVoiceRoomTranscript();
    }

    // _____________________________________________________________________
    // REUNIONES CON VOZ: al convocar, se abre la llamada con los asistentes
    // _____________________________________________________________________
    function agentParticipant(a) {
      return { id: a.id, agentId: a.id, name: a.name, role: a.role, color: '#' + new THREE.Color(a.color).getHexString() };
    }

    const _baseConvokeMeeting = convokeMeeting;
    convokeMeeting = function (zoneId) {
      // el Director puede convocar aunque sea hora de descanso: quien está en pausa del horario acude
      const office = (ZONES[zoneId] && ZONES[zoneId].office) || 'main';
      if (!MEETING.active) AGENTS.forEach(a => {
        if (a._schedBreak && a.status === 'break' && !a.leaving && officeOf(a) === office) { a._schedBreak = false; a.status = 'working'; a.breakMinUntil = 0; }
      });
      _baseConvokeMeeting(zoneId);
      if (!MEETING.active || MEETING.active.zone !== zoneId) return;
      MEETING.active.endsAt = performance.now() + 30 * 60000; // la reunión dura lo que dure la llamada
      const people = MEETING.active.attendees.map(id => AGENTS.find(a => a.id === id)).filter(Boolean);
      const lead = people.slice().sort((a, b) => (b.rankIdx || 0) - (a.rankIdx || 0))[0];
      openVoiceRoom({
        kind: 'meeting',
        title: 'Reunión · ' + ZONES[zoneId].name.replace(/^\S+\s/, ''),
        subtitle: people.length + ' asistentes',
        participants: people.map(agentParticipant),
        greeting: lead ? [{ id: lead.id, text: `Buenas, ${COMPANY.independent ? COMPANY.owner : 'Director'}. Estamos todos. ¿De qué quieres que hablemos?` }] : [],
        onUserSay: meetingReplies,
        onClose: () => { if (MEETING.active) endMeeting(); }
      });
      if (typeof setCameraPreset === 'function' && !DIR3D.active) desiredCameraTarget.set(ZONES[zoneId].x, 1, ZONES[zoneId].z);
    };

    const _baseEndMeeting = endMeeting;
    endMeeting = function () {
      const wasMeeting = !!MEETING.active;
      _baseEndMeeting();
      if (wasMeeting && ROOM.open && ROOM.kind === 'meeting') closeVoiceRoom(true);
    };

    function officeSnapshot() {
      const mine = PROJECTS.filter(p => p.officeId === ACTIVE_OFFICE);
      return {
        empresa: BRAND,
        hora: new Date().toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit' }),
        bloque_horario: typeof currentScheduleBlock === 'function' ? currentScheduleBlock().label : '',
        equipo: AGENTS.filter(a => a.type === 'AI' && !a.leaving && officeOf(a) === ACTIVE_OFFICE).length,
        proyectos_en_curso: mine.filter(p => p.status === 'en_curso').map(p => ({ titulo: p.title, avance: projectProgressPct(p) + '%', responsable: (projectAgent(p) || {}).name || 'sin asignar' })),
        por_revisar: mine.filter(p => p.status === 'revision').map(p => p.title),
        terminados: mine.filter(p => p.status === 'terminado').length,
        entregables: DELIVERABLES.length
      };
    }

    async function meetingReplies(text, transcript) {
      const people = ROOM.participants.map(p => AGENTS.find(a => a.id === p.agentId)).filter(Boolean);
      const cmd = typeof runOfficeCommand === 'function' ? runOfficeCommand(text, { silent: true }) : null;
      if (aiReady()) {
        try {
          const roster = people.map(a => `- ${a.name}: ${a.role} (${rankOf(a).name})`).join('\n');
          const system = `Simulas una reunión de trabajo real en la oficina virtual de la empresa "${BRAND}". Los empleados son IA y hablan en español, en frases cortas y naturales para leer en voz alta (máximo 2 frases cada uno).
Responden 1 o 2 empleados, los más relevantes; si el Director nombra a alguien, responde esa persona. Son profesionales, concretos y motivados. Nunca inventan proyectos que el Director no ordenó.
Asistentes:\n${roster}`;
          const history = transcript.slice(-12).map(t => `${t.who}: ${t.text}`).join('\n');
          const ctx = `Estado de la empresa: ${JSON.stringify(officeSnapshot())}${cmd ? `\nAcción ya ejecutada por la oficina: ${cmd}` : ''}\n\nConversación:\n${history}\n\nResponde al último mensaje del Director.`;
          const out = await aiJson(system, [{ role: 'user', content: ctx }], {
            type: 'object',
            properties: { respuestas: { type: 'array', items: { type: 'object', properties: { nombre: { type: 'string' }, texto: { type: 'string' } }, required: ['nombre', 'texto'], additionalProperties: false } } },
            required: ['respuestas'], additionalProperties: false
          });
          const list = (out.respuestas || []).slice(0, 3).map(r => ({ name: r.nombre, text: String(r.texto).slice(0, 300) }));
          if (list.length) return list;
        } catch (e) {
          showToast('⚠️ ' + aiErrorMessage(e) + ' Respondo con la lógica local.');
        }
      }
      return localMeetingReplies(text, people, cmd);
    }

    function localMeetingReplies(text, people, cmd) {
      if (!people.length) return [];
      const low = text.toLowerCase();
      const named = people.find(a => low.includes(a.name.replace(/ IA$/, '').toLowerCase()));
      const pick = (n) => {
        const list = named ? [named] : people.slice().sort(() => Math.random() - 0.5);
        return list.slice(0, n);
      };
      const boss = COMPANY.independent ? COMPANY.owner : 'Director';
      if (cmd) return [{ id: pick(1)[0].id, text: `Hecho, ${boss}. ${cmd} Nos ponemos con ello ahora mismo.` }];
      if (/avance|progreso|c[oó]mo va|estado|proyecto/.test(low)) {
        const running = PROJECTS.filter(p => p.officeId === ACTIVE_OFFICE && (p.status === 'en_curso' || p.status === 'revision'));
        if (!running.length) return [{ id: pick(1)[0].id, text: `Ahora mismo no hay proyectos en curso. En cuanto nos ordenes uno, arrancamos.` }];
        return running.slice(0, 2).map(p => {
          const a = projectAgent(p) || pick(1)[0];
          const who = people.includes(a) ? a : pick(1)[0];
          return { id: who.id, text: p.status === 'revision' ? `${p.title} ya está terminado y espera tu revisión.` : `${p.title} va al ${projectProgressPct(p)} por ciento. Ahora: ${p.steps[Math.min(p.stepIndex, p.steps.length - 1)].desc.toLowerCase()}.` };
        });
      }
      if (/idea|propuesta|suger|mejorar|opin/.test(low)) {
        const ideas = ['podríamos crear una plantilla reutilizable para acelerar las webs', 'propongo revisar el rendimiento en móviles antes de cada entrega', 'convendría documentar mejor cada proyecto para los clientes', 'sería útil una sesión de pruebas cruzadas entre equipos'];
        return pick(2).map((a, i) => ({ id: a.id, text: `Desde ${a.role.split(' ')[0]}, ${ideas[(officeHash(a.id) + i) % ideas.length]}. Si te parece bien, lo ordenas y lo hacemos.` }));
      }
      if (/gracias|bien hecho|felicit|excelente|buen trabajo|genial/.test(low)) {
        return pick(2).map(a => ({ id: a.id, text: randPick(['¡Gracias! Así da gusto trabajar.', 'Gracias a ti por la confianza, seguimos con todo.', '¡Gracias! El equipo está con mucha energía.']) }));
      }
      if (/problema|bloque|error|fallo|ayuda/.test(low)) {
        return pick(1).map(a => ({ id: a.id, text: 'Lo revisamos ahora mismo. Si es un fallo, Lucas lo reproduce en QA y lo corregimos antes de la entrega.' }));
      }
      if (/objetivo|meta|semana|mes|plan/.test(low)) {
        return pick(2).map(a => ({ id: a.id, text: randPick(['Anotado como objetivo del equipo. Lo priorizamos en el tablero.', 'Perfecto, lo dividimos en tareas y te informamos del avance.']) }));
      }
      return pick(1).map(a => ({ id: a.id, text: randPick([`Entendido, ${boss}. Lo tenemos en cuenta.`, 'De acuerdo. ¿Quieres que lo convirtamos en un proyecto?', 'Claro. Lo comentamos con el resto del equipo y seguimos.']) }));
    }
